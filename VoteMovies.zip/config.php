<?php 
define('DB_HOST','localhost');
define('DB_USER','root');   //数据库的账号
define('DB_PWD','');       //数据库的密码
define('DB_NAME','votemovie');  //数据库的名字
define('DB_PORT','3306');
define('DB_TYPE','mysql');
define('DB_CHARSET','utf8');